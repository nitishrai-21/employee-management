<?php

namespace App\Http\Controllers;

use App\Jobs\ImportCsvJob;
use League\Csv\Reader;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Validator;
use App\Models\Employee;
use Illuminate\Support\Facades\Storage;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $employees = Employee::select('*')->paginate(100);
        return response()->json(array(
            'status' => true,
            'message' => 'List of all the employees',
            'errors' => [],
            'data' => $employees
        ), 200);
    }

    public function show(string $id)
    {
        $emp_obj = Employee::where('emp_id', $id)->first();

        if (is_null($emp_obj)) {
            return response()->json(array(
                'status' => false,
                'message' => 'No such employee exist with Emp Id: ' . $id,
                'errors' => 'No such employee exist with Emp Id: ' . $id,
                'data' => []
            ), 422);
        }
        
        return response()->json(array(
            'status' => true,
            'message' => 'Details of the employee having Emp Id:'. $id,
            'errors' => [],
            'data' => $emp_obj
        ), 200);
    }

    public function import(Request $request)
    {
        set_time_limit(180);
        $err_file_name = 'csv_import_errors-'.date('Y-m-d').'log';
        // Validate file upload
        $validator = Validator::make($request->all(), [
            'csv_file' => 'required|file|mimes:csv,txt|max:10000',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => 'Invalid file format or size'], 400);
        }

        $file = $request->file('csv_file');
        $filePath = $file->getRealPath();

        // Create CSV reader
        $csv = Reader::createFromPath($filePath, 'r');
        $csv->setHeaderOffset(0); // First row is header
        $records = $csv->getRecords();

        // Get total records count
        $totalRecords = iterator_count($records);
        $chunkSize = 1000; // Number of records per job
        $start_time = date('d/m/Y h:i:s a', time());
        // Dispatch jobs for each chunk
        for ($offset = 0; $offset < $totalRecords; $offset += $chunkSize) {
            ImportCsvJob::dispatch($filePath, $offset, $chunkSize);
        }
        return response()->json(['message' => 'CSV imported successfully (Visit the link to see the errors identified in todays import: http://127.0.0.1:8000/api/logs-files/'.$err_file_name.')']);
    }

    public function logsFiles($file_name)
    {
        $file_location = storage_path('logs/').$file_name;
        if (file_exists($file_location)) {
            return response()->download($file_location, $file_name, ['Content-Type' => mime_content_type($file_location)]);
        } else {
            return response()->json(array(
                'status' => false,
                'message' => 'File Not Found',
                'errors' => [],
                'data' => $file_name
            ), 404);
        }
    }

    public function destroy(string $id)
    {
        $emp_obj = Employee::where('emp_id', $id)->first();

        if (is_null($emp_obj)) {
            return response()->json(array(
                'status' => false,
                'message' => 'No such employee exist with Emp Id: ' . $id,
                'errors' => 'No such employee exist with Emp Id: ' . $id,
                'data' => []
            ), 422);
        }
        Employee::where('emp_id', $id)->delete();
        $employees = Employee::select('*')->paginate(100);
        return response()->json(array(
            'status' => true,
            'message' => 'Employee with Emp Id:'.$id.' deleted successfully',
            'errors' => [],
            'data' => $employees
        ), 200);
    }
}
