<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use League\Csv\Reader;
use App\Models\Employee;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class ImportCsvJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $filePath;
    protected $offset;
    protected $limit;

    /**
     * Create a new job instance.
     *
     * @param string $filePath
     * @param int $offset
     * @param int $limit
     */
    public function __construct($filePath, $offset, $limit)
    {
        $this->filePath = $filePath;
        $this->offset = $offset;
        $this->limit = $limit;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $csv = Reader::createFromPath($this->filePath, 'r');
        $csv->setHeaderOffset(0); // Assuming first row contains headers

        $records = $csv->getRecords();
        $records->seek($this->offset);

        $chunk = iterator_to_array($records, false);
        $chunk = array_slice($chunk, ($this->offset+1), $this->limit);
        $errors = [];
        // Process the chunk of records
        foreach ($chunk as $index => $record) {
            DB::beginTransaction();
            try {
                // insert into the database
                Employee::create([
                    // 'column1' => $record['column1'],
                    'emp_id' => $record["Emp ID"],
                    'name_prefix'=> $record["Name Prefix"],
                    'first_name'=> $record["First Name"],
                    'middle_initial'=> $record["Middle Initial"],
                    'last_name'=> $record["Last Name"],
                    'gender'=> $record["Gender"],
                    'email'=> $record["E Mail"],
                    'date_of_birth'=> date("Y/m/d", strtotime($record["Date of Birth"])),
                    'time_of_birth'=> $record["Time of Birth"],
                    'age_in_yrs'=> $record["Age in Yrs."],
                    'date_of_joining'=> date("Y/m/d", strtotime($record["Date of Joining"])),
                    'age_in_company_yrs'=> $record["Age in Company (Years)"],
                    'phone_no'=> $record["Phone No. "],
                    'place_name'=> $record["Place Name"],
                    'country'=> $record["County"],
                    'city'=> $record["City"],
                    'zip'=> $record["Zip"],
                    'region'=> $record["Region"],
                    'user_name'=> $record["User Name"]
                ]);
            DB::commit();
            } catch (\Exception $e) {
                // If there's any exception (e.g., database errors), log the error
                DB::rollBack();
                Log::channel('csv_errors')->error('Row: ' . ($this->offset + $index + 1) . ' Exception: ' . $e->getMessage());
            }
        }
    }
}

