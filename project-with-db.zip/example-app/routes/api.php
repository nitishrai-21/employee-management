<?php

use App\Http\Controllers\EmployeeController;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('test', function () {
    return 'Hello';
});
//import csv route
Route::post('employee', [EmployeeController::class, 'import']);
//list all the employees
Route::get('employee/list', [EmployeeController::class, 'index']);
//find an employee with id
Route::get('employee/{id}', [EmployeeController::class, 'show']);
//delete an employee with id
Route::post('employee/{id}', [EmployeeController::class, 'destroy']);

//serve the error log files
Route::get('logs-files/{filename}', [EmployeeController::class, 'logsFiles']);
